<!DOCTYPE html>
<html>
<head>
	<title>Login And Signup Form</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	
	<link rel="stylesheet" type="text/css" href="Login.css">
</head>
<body>

	<!------Navigation Bar------->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a  class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Gallery.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Hotel.php">Hotels</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Sign-Up.php">Sign-Up</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
				</ul>
			</div>
			
		</div>
	</nav>
	<!---------Login------------>

	<section class="container-fluid">
		<section class="row justify-content-center">
			<section class="col-12 clo-sm-6 col-md-3 mt-5">
	<form class="form-container" action="validation.php" method="post">
   <div class="form-group">
    <label for="user name" class="text-primary">User Name</label>
    <input type="user name" class="form-control" name="uname">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <br>
  <div class="form-group">
    <label for="Password" class="text-primary">Password</label>
    <input type="password" class="form-control" name="Password">
  </div>
  <br>
 
  <button type="submit" class="btn btn-primary">Login</button>
  <button class="btn btn-dark " type="reset" value="Reset">Reset</button>
</form>
</section>
</section>
</section>


	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>