<!DOCTYPE html>
<html>
<head>
	<title>Login And Signup Form</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	
	<link rel="stylesheet" type="text/css" href="Sign-Up.css">
</head>
<body>

	<!------Navigation Bar------->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a  class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Gallery.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Hotel.php">Hotels</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Sign-Up.php">Sign-Up</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
				</ul>
			</div>
			
		</div>
	</nav>
	<!---------Sign-Up------------>

	<section class="container-fluid">
	<section class="row justify-content-center">
	<section class="col-12 clo-sm-6 col-md-3 mt-5">
	<form class="form-container" action="Registration.php" method="post">

   <div class="input-group flex-nowrap">
  <span class="input-group-text text-primary">@</span>
  <input type="text" name="fname" class="form-control" placeholder="First Name">
  </div><br>
   
  <div class="input-group flex-nowrap">
  <span class="input-group-text text-primary">@</span>
  <input type="text" name="lname" class="form-control" placeholder="Last Name">
  </div><br>

  <div class="input-group flex-nowrap">
  <span class="input-group-text text-primary">@</span>
  <input type="text" name="uname" class="form-control" placeholder="User Name">
  </div><br>

<div class="input-group flex-nowrap">
  <span class="input-group-text text-primary">@</span>
  <input type="text" name="email" class="form-control" placeholder="Email Address">
  </div><br>

<div class="input-group flex-nowrap">
  <span class="input-group-text text-primary">@</span>
  <input type="text" name="password" class="form-control" placeholder="Password">
 </div><br>



  <div class="form-group form-check">
   <input type="checkbox" class="form-check-input" id="Check">
   <label class="form-check-label text-primary" for="Check">Check me out</label>
  </div>
  <br>
  <button type="submit" class="btn btn-dark btn-lg">Sign-Up</button>
  <button class="btn btn-dark btn-lg" type="reset" value="Reset">Reset</button>
</form>
</section>

</section>
</section>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>