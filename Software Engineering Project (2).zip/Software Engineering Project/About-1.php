<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	
	<link rel="stylesheet" type="text/css" href="About.css">
</head>
<body>
	
	<!------Navigation Bar------->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a  class="nav-link" href="Home-1.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About-1.php">About Us</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Gallery-1.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Hotel-1.php">Hotels</a>
					</li>
					<li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Room</a>
						<div class="dropdown-menu dropdown-menu-dark">

                            <a href="Single Room.php" class="dropdown-item">Single Room</a>
							<a href="Double Room.php" class="dropdown-item">Double Room</a>
							<a href="Triple Room.php" class="dropdown-item">Triple Room</a>
							
							
							
							</div>
					   </li>
					   <li class="nav-item">
						<a   class="nav-link" href="Contact-1.php">Contact</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Logout.php">Logout</a>
					</li>
					
				</ul>
			</div>
			
		</div>
	</nav>
	<!----------About Us Header------->

	<section id="head" class="text-center text-light">
		<div class="container">
			<div class="row">
				<div class="col mt-4 pt-4">
					<h2>About Us</h2>
					<p class="lead">Hello,Welcome to Visit Our Website</p>
					
				</div>
				
			</div>
			
		</div>
		
	</section>

	<!-----About Info-------->

	<section id="info" class="py-5">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<h2>Hotel Booking System :</h2>
					<p class="lead text-justify">The name of our project is Hotel Booking System. The purpose of this project to show the popular hotel of Sylhet City (further we can add other city). In this website users can see nearby hotels locations and details of hotel. Hotel booking system is the best platform, as it adds many benefits and user can easily book the hotel or room through the internet. It discovers the more and information about a hotel which is situated in a particular area and user can also select a hotel according to his/her demands and choice.</p>
					
				</div>
				<div class="col-md-6 text-right">
					<img src="9.jpg" class="img-fluid rounded">
					
				</div>
				
			</div>
			
		</div>
		
	</section>

	<!---------Copyrights--------->

<section id="copyright" class="text-center py-3 text-info mt-2">
	<div class="container">
		<div class="row">
			<div class="col">
				<p class="lead mb-0">All Copyright Reserved 2021 &copy; Hotel Booking System ( Team-M Square )</p>
				
			</div>
			
		</div>
		
	</div>
	
</section>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>


</body>
</html>