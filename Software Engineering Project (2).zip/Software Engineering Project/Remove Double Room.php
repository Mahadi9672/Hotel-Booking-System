<!DOCTYPE html>
<html>
<head>
	<title>Remove Double Room</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="Admin.css">
</head>
<body>
	<!---Navigation Part--->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="Admin.php" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					 <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">ADD</a>
						<div class="dropdown-menu dropdown-menu-dark">

                           <a href="Add Hotel.php" class="dropdown-item">Add Hotel</a>
						    <a href="Add Single Room.php" class="dropdown-item">Add Single Room</a>
						   <a href="Add Double Room.php" class="dropdown-item">Add Double Room</a>
						   <a href="Add Triple Room.php" class="dropdown-item">Add Triple Room</a>
						</div>
					   </li>

					 <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">DELETE</a>
						<div class="dropdown-menu dropdown-menu-dark">

                           <a href="Delete Hotel.php" class="dropdown-item">Delete Hotel</a>
						   <a href="Delete Single Room.php" class="dropdown-item">Delete Single Room</a>
						   <a href="Delete Double Room.php" class="dropdown-item">Delete Double Room</a>
						   <a href="Delete Triple Room.php" class="dropdown-item">Delete Triple Room</a>
						</div>
					   </li>
                       
                    <li class="nav-item">
					<a  class="nav-link" href="User Management.php">User Management</a>
					</li>

					   <li class="nav-item">
						<a  class="nav-link" href="Booking Details.php">Booking Details</a>
					</li>

					<li class="nav-item">
						<a  class="nav-link" href="Contact info.php">Contact info</a>
					</li>


					
										
				</ul>
			</div>
			
		</div>
	</nav>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>

<?php
    session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'software project');


	$name=$_GET['rn'];
	$query="delete from double_room where name='$name'";
	$data=mysqli_query($con,$query);
	if($data){
	echo "<br>";
	echo "<h1><center>Record Deleted Form Database</h1></center>";
	
	}
	else{
	echo "<br>";
	echo "<h1><center>Failed to delete</h1></center>";
	}
	?>