<!DOCTYPE html>
<html>
<head>
	<title>Learn Bootstrap</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<!---Navigation Part--->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a  class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Gallery.php">Gallery</a>
					</li>

					   <li class="nav-item">
						<a  class="nav-link" href="Hotel.php">Hotel</a>
					</li>
					  <li class="nav-item">
						<a  class="nav-link" href="Sign-Up.php">Sign-Up</a>
					</li>
                       <li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
				</ul>
			</div>
			
		</div>
	</nav>

	<!-----Slider Part------>

<section id="showcase" class="bg-dark">
<div id="carousel" class="carousel slide" data-bs-ride="carousel">
  <ol class="carousel-indicators">
    <li data-bs-target="#carousel" data-bs-slide-to="0" class="active"></li>
    <li data-bs-target="#carousel" data-bs-slide-to="1"></li>
    <li data-bs-target="#carousel" data-bs-slide-to="2"></li>
    <li data-bs-target="#carousel" data-bs-slide-to="3"></li>
  </ol>
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="6.jpg" class="d-block w-100" alt="First Slide">
    </div>
    <div class="carousel-item">
      <img src="2.jpg" class="d-block w-100" alt="Second Slide">
    </div>
    <div class="carousel-item">
      <img src="4.jpg" class="d-block w-100" alt="Third Slide">
    </div>
     <div class="carousel-item">
      <img src="1.jpg" class="d-block w-100" alt="Fourth Slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carousel" role="button" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel" role="button" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </a>
</div>
</section>




<!------Info Section------>

<section id="info" class="py-5">
	<div class="container">
		<div class="row">
			<div class="col-md-6 align-self-center">
			<h3>HBS Important</h3>
			<p>Hotel booking system is the best platform, as it adds many benefits and user can easily book the hotel or room through the internet. It discovers the more information about a hotel which is situated in a particular area and user can also select a hotel according to his/her demands and choice.</p>
			<a href="About.php" class="btn btn-outline-dark">Read More</a>
			</div>
			<div class="col-md-6">
				<img src="6.jpg" class="img-fluid rounded" alt="PC">
				
			</div>
			
		</div>
		
	</div>
	
</section>

<!-------Get Started---->

<section id="getstarted" class="py-5 text-center text-light">
	<div class="dark-overlay">
		<div class="container">
			<div class="row">
				<div class="col mt-3 pt-3">
					<h2>Are You Ready To Get Started</h2>
					<p class="lead">If you are interested to stay with us and wants to get benefit through our website
						you have to registered.Then take benefit of Booking Hotels and more.We Welcome you advance.</p>
					
				</div>
				
			</div>
			
		</div>
		
	</div>
	
</section>

<!---------Copyrights--------->

<section id="copyright" class="text-center py-3 text-info mt-2">
	<div class="container">
		<div class="row">
			<div class="col">
				<p class="lead mb-0"> All Copyright Reserved 2021 &copy; Hotel Booking System ( Team-M Square )</p>
				
			</div>
			
		</div>
		
	</div>
	
</section>



	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>