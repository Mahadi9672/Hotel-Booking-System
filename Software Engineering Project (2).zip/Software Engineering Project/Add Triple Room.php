 <!DOCTYPE html>
<html>
<head>
	<title>Add Triple Room</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<!---Navigation Part--->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="Admin.php" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					 <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">ADD</a>
						<div class="dropdown-menu dropdown-menu-dark">

                           <a href="Add Hotel.php" class="dropdown-item">Add Hotel</a>
						    <a href="Add Single Room.php" class="dropdown-item">Add Single Room</a>
						   <a href="Add Double Room.php" class="dropdown-item">Add Double Room</a>
						   <a href="Add Triple Room.php" class="dropdown-item">Add Triple Room</a>
						</div>
					   </li>

					 <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">DELETE</a>
						<div class="dropdown-menu dropdown-menu-dark">

                           <a href="Delete Hotel.php" class="dropdown-item">Delete Hotel</a>
						   <a href="Delete Single Room.php" class="dropdown-item">Delete Single Room</a>
						   <a href="Delete Double Room.php" class="dropdown-item">Delete Double Room</a>
						   <a href="Delete Triple Room.php" class="dropdown-item">Delete Triple Room</a>
						</div>
					   </li>
                       
                    <li class="nav-item">
					<a  class="nav-link" href="User Management.php">User Management</a>
					</li>

					   <li class="nav-item">
						<a  class="nav-link" href="Booking Details.php">Booking Details</a>
					</li>

					<li class="nav-item">
						<a  class="nav-link" href="Contact info.php">Contact info</a>
					</li>


					
										
				</ul>
			</div>
			
		</div>
	</nav>

	<!-------Add Hotel------------>

	<section id="Contact" class="py-5 bg-light">
		<div class="container">
			<div class="row">
				<div class="col-lg-9">
					<div class="info-contact">
						<h2 class="display-4 text-center">Add Triple Room</h2><br>
						
						
					</div>
					<form  method="post">
						<div>
							<input type="text" name="name" placeholder="Hotel Name" class="form-control form-control-lg" required>
						</div><br>
						
						<div>
							<input type="file" name="image" placeholder="Add Image" class="form-control form-control-lg" required>
						</div><br>

						<div>
							<input type="text" name="description" placeholder="Description" class="form-control form-control-lg" required>
						</div><br>

						<div>
							<input type="number" name="adult" placeholder="Max Adult" class="form-control form-control-lg" required>
						</div><br>

						<div>
							<input type="number" name="child" placeholder="Max Child" class="form-control form-control-lg" required>
						</div><br>

						<div>
							<input type="number" name="no_of_bed" placeholder="No Of Bed" class="form-control form-control-lg" required>
						</div><br>

						<div>
							<input type="text" name="facility" placeholder="Room Facility" class="form-control form-control-lg" required>
						</div><br>

							<div>
							<input type="number" name="price" placeholder="Price" class="form-control form-control-lg" required>
						</div><br>

							<div>
							<input type="text" name="location" placeholder="Hotel Location" class="form-control form-control-lg" required>
						</div><br>
							
							

							<button name="submit" type="submit" class="btn btn-primary btn-lg">SUBMIT</button>
							<button class="btn btn-dark btn-lg" type="reset" value="Reset">Reset</button>
					</form>
					
				</div>
				
			</div>
			
		</div>
		
	</section>
   
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>



<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'software project');
	
	if(isset($_POST['submit']))
	{
		$g=$_POST['name'];
		$h=$_POST['image'];
		$i=$_POST['description'];
		$j=$_POST['adult'];
		$k=$_POST['child'];
		$l=$_POST['no_of_bed'];
		$m=$_POST['facility'];
		$n=$_POST['price'];
		$o=$_POST['location'];
		
		$qry="INSERT INTO triple_room (name,image,description,adult,child,no_of_bed,facility,price,location) VALUES('$g','$h','$i','$j','$k','$l','$m','$n','$o')";
		mysqli_query($con,$qry);

	}
	
?>

