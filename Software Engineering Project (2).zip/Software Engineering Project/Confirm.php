<!DOCTYPE html>
<html>
<head>
	<title>Hotel Details</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	
	<link rel="stylesheet" type="text/css" href="Single Room.css">
</head>
<body>
	<!------Navigation Bar------->
	
	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a  class="nav-link" href="Home-1.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About-1.php">About Us</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Gallery-1.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Hotel-1.php">Hotels</a>
					</li>
					  <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Room</a>
						<div class="dropdown-menu dropdown-menu-dark">

                           <a href="Single Room.php" class="dropdown-item">Single Room</a>
							<a href="Double Room.php" class="dropdown-item">Double Room</a>
							<a href="Triple Room.php" class="dropdown-item">Triple Room</a>
							<a href="Quad Room.php" class="dropdown-item">Quad Room</a>
							
							
							</div>
					   </li>
					   <li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Logout.php">Logout</a>
					</li>
					
				</ul>
			</div>
			
		</div>
	</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>


<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'software project');

$hotel=$_POST['hotel'];
$room=$_POST['room'];
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$payment=$_POST['payment'];
$transaction=$_POST['transaction'];
$amount=$_POST['amount'];
$check_in=$_POST['check_in'];
$check_out=$_POST['check_out'];

$s="select * from booking";
$result=mysqli_query($con,$s);
$rr="insert into booking(hotel,room,name,email,mobile,payment,transaction,amount,check_in,check_out) values ('$hotel','$room','$name','$email','$mobile','$payment','$transaction','$amount','$check_in','$check_out')";
mysqli_query($con,$rr);
echo "<br>";
echo "<h1><center>Your Booking Successfully</center></h1>";

?>