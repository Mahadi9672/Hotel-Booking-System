<!DOCTYPE html>
<html>
<head>
	<title>Gallery Photo</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="Gallery.css">
	
</head>
<body>
	<!-----Navigation Part--------->

        <nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item">
						<a  class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>
					<li class="nav-item active">
						<a  class="nav-link" href="Gallery.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Hotel.php">Hotels</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Sign-Up.php">Sign-Up</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
				</ul>
			</div>
			
		</div>
	</nav> 
	

<!-------Gallery Part-------->

    <section id="gallery" class="py-5" uk-lightbox>
		<div class="container">
			<div class="row text-center">
				<div class="col">
					<h2>Gallery Of Hotels Room</h2>
					<p class="lead">Check Out Our Photo</p>
				</div>
			</div>
			
			
		
			
			
			<div class="row pt-3">
				<div class="col-md-4">
					<div>
						<a href="Noorjahan/1.jpg">
						<img src="Noorjahan/1.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Noorjahan/2.jpg">
						<img src="Noorjahan/2.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Noorjahan/3.jpg">
						<img src="Noorjahan/3.jpg" class="img-fluid" alt="">
						</a>
					</div>
					
				</div>
			</div>
			<div class="row pt-3">
				<div class="col-md-4">
					<div>
						<a href="Britania/1.jpg">
						<img src="Britania/1.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Richmond/3.jpg">
						<img src="Richmond/3.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Richmond/4.jpg">
						<img src="Richmond/4.jpg" class="img-fluid" alt="">
						</a>
					</div>
					
				</div>
			</div>
			<div class="row pt-3">
				<div class="col-md-4">
					<div>
						<a href="Rose view/2.jpg">
						<img src="Rose view/2.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Rose view/3.jpg">
						<img src="Rose view/3.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Rose view/4.jpg">
						<img src="Rose view/4.jpg" class="img-fluid" alt="">
						</a>
					</div>
					
				</div>
			</div>
			<div class="row pt-3">
				<div class="col-md-4">
					<div>
						<a href="Star Pacific/1.jpg">
						<img src="Star Pacific/1.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Star Pacific/3.jpg">
						<img src="Star Pacific/3.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Star Pacific/5.jpg">
						<img src="Star Pacific/5.jpg" class="img-fluid" alt="">
						</a>
					</div>
					
				</div>
			</div>
			<div class="row pt-3">
				<div class="col-md-4">
					<div>
						<a href="Supreme/2.jpg">
						<img src="Supreme/2.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Supreme/3.jpg">
						<img src="Supreme/3.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Supreme/12.jpg">
						<img src="Supreme/12.jpg" class="img-fluid" alt="">
						</a>
					</div>
					
				</div>
			</div>
			<div class="row pt-3">
				<div class="col-md-4">
					<div>
						<a href="Valley Garden/4.jpg">
						<img src="Valley Garden/4.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Valley Garden/3.jpg">
						<img src="Valley Garden/3.jpg" class="img-fluid" alt="">
						</a>
					</div>
				</div>
				<div class="col-md-4">
					<div>
						<a href="Valley Garden/5.jpg">
						<img src="Valley Garden/5.jpg" class="img-fluid" alt="">
						</a>
					</div>
					
				</div>
			</div>

		</div>

		
	</section>
	

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>