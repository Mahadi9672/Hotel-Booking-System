<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'software project');
?>


<!DOCTYPE html>
<html>
<head>
	<title>Hotel Details</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	
	<link rel="stylesheet" type="text/css" href="Hotel.css">
</head>
<body>
	<!------Navigation Bar------->
	
	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a  class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Gallery.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Hotel.php">Hotels</a>
					</li>
					  <li class="nav-item">
						<a  class="nav-link" href="Sign-Up.php">Sign-Up</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
				</ul>
			</div>
			
		</div>
	</nav>

	<!-----About Info-------->
	
	<section id="info" class="py-5">
		       <?php
		       $qry="select * from hotel";
		       $result=mysqli_query($con,$qry);
		       while($row=mysqli_fetch_assoc($result)){
	           ?>
		    <div class="container">
			<div class="row">
			<div class="col-md-6 text-right">
			<img src="<?php echo $row['image']; ?>" class="img-fluid rounded">

					<div>
						<br><br>
					</div>

				</div>

			
				
				<div class="col-md-6">
					<h2 class="text-primary"><?php echo $row['name']; ?></h2>

					<p class="text-justify"><?php echo $row['first']; ?><p>

					 <p class="text-justify"><?php echo $row['second']; ?></p>

					 <p class="text-justify "><?php echo $row['third']; ?></p>

					 <p class="text-justify"><?php echo $row['fourth']; ?></p> 
					</div><br>

					<?php
		            }
		            ?>

				    
			</div>
			
				    
			</div>
			

				    

		
	</section>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
</body>
</html>