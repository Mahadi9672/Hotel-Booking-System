<!DOCTYPE html>
<html>
<head>
	<title>Login And Signup Form</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	
	<link rel="stylesheet" type="text/css" href="Sign-Up.css">
</head>
<body>

	<!------Navigation Bar------->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="index.html" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a  class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="About.php">About Us</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Gallery.php">Gallery</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Hotel.php">Hotels</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Sign-Up.php">Sign-Up</a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="Login.php">Login</a>
					</li>
					<li class="nav-item">
						<a   class="nav-link" href="Contact.php">Contact</a>
					</li>
				</ul>
			</div>
			
		</div>
	</nav>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>



<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'software project');
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$email=$_POST['email'];
$password=$_POST['password'];

$s="select * from register where uname='$uname'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	echo "<br>";
	echo "<h1><center>User Name Already Taken .Try with another one</h1></center> ";
}	
else{
    $rr="insert into register(fname,lname,uname,email,password) values ('$fname','$lname','$uname','$email','$password')";
	mysqli_query($con,$rr);
	echo "<br>";
	echo "<h1><center>Registration Successful</h1></center>";
}
?>