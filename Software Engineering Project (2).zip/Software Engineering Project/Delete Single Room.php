<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'software project');
?>


<!DOCTYPE html>
<html>
<head>
	<title>Delete Single Room</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<!---Navigation Part--->

	<nav class="navbar navbar-dark bg-dark navbar-expand-md">
		<div class="container">
			<a href="Admin.php" class="navbar-brand">Hotel Booking System Website</a>
			<button class="navbar-toggler navbar-toggler-right">
			
			</button>
			<div>
				<ul class="navbar-nav">
					 <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">ADD</a>
						<div class="dropdown-menu dropdown-menu-dark">

                           <a href="Add Hotel.php" class="dropdown-item">Add Hotel</a>
						    <a href="Add Single Room.php" class="dropdown-item">Add Single Room</a>
						   <a href="Add Double Room.php" class="dropdown-item">Add Double Room</a>
						   <a href="Add Triple Room.php" class="dropdown-item">Add Triple Room</a>
						</div>
					   </li>

					 <li class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">DELETE</a>
						<div class="dropdown-menu dropdown-menu-dark">

                           <a href="Delete Hotel.php" class="dropdown-item">Delete Hotel</a>
						   <a href="Delete Single Room.php" class="dropdown-item">Delete Single Room</a>
						   <a href="Delete Double Room.php" class="dropdown-item">Delete Double Room</a>
						   <a href="Delete Triple Room.php" class="dropdown-item">Delete Triple Room</a>
						</div>
					   </li>
                       
                    <li class="nav-item">
					<a  class="nav-link" href="User Management.php">User Management</a>
					</li>

					   <li class="nav-item">
						<a  class="nav-link" href="Booking Details.php">Booking Details</a>
					</li>

					<li class="nav-item">
						<a  class="nav-link" href="Contact info.php">Contact info</a>
					</li>


					
										
				</ul>
			</div>
			
		</div>
	</nav>

	<!-------Add Hotel------------>

	<section id="info" class="py-5">
		      <?php
		       $qry="select * from rooms";
		       $result=mysqli_query($con,$qry);
		       while($row=mysqli_fetch_assoc($result)){
	           ?>
		<div class="container">
			<div class="row">
				<div class="col-md-6 text-right">
					<img src="<?php echo $row['image']; ?>" class="img-fluid rounded">

					<div>
						<br><br>
					</div>

				</div>

			
				
				<div class="col-md-6">
					<h2 class="text-primary"><?php echo $row['name']; ?></h2>

					<p class="text-justify"><?php echo $row['description']; ?><p>

					 <p class="text-justify"> <?php echo $row['adult']; ?></p>

					 <p class="text-justify">  <?php echo $row['child']; ?></p>

					 <p class="text-justify"> <?php echo $row['no_of_bed']; ?></p>

					  <p class="text-justify"> <?php echo $row['facility']; ?></p> 


					   <p class="text-justify"> <?php echo $row['price']; ?></p>  

					    <p class="text-justify"> <?php echo $row['location']; ?></p> 

					 <a  class="btn btn-dark" href="Remove Room.php?rn=<?php echo $row['name'];?>">Delete</a>
					</div>

					<?php
		            }
		            ?>

				    
			</div>
			
		</div>
		
	</section>
   
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</body>
</html>